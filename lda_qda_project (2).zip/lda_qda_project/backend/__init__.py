"""Backend package for the LDA/QDA project."""
