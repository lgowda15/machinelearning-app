"""Common model interface supplied by the integration platform."""

from abc import ABC, abstractmethod
from typing import Any

import numpy as np
from numpy.typing import NDArray


class BaseModel(ABC):
    """Common interface for all models in the integration platform."""

    def __init__(self, **hyperparams: Any) -> None:
        self.hyperparams = hyperparams
        self.is_fitted = False
        self.n_features: int | None = None

    @abstractmethod
    def fit(
        self,
        X: NDArray[np.float64],
        y: NDArray[Any] | None = None,
    ) -> "BaseModel":
        """Train the model and return self."""

    @abstractmethod
    def predict(self, X: NDArray[np.float64]) -> NDArray[Any]:
        """Return one class label per input row."""

    @abstractmethod
    def predict_proba(self, X: NDArray[np.float64]) -> NDArray[np.float64] | None:
        """Return class probabilities in ``classes_`` order."""

    @abstractmethod
    def get_metadata(self) -> dict[str, Any]:
        """Return the platform metadata dictionary."""
