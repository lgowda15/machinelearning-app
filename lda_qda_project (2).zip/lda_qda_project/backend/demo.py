"""Runnable demo: fit LDA and QDA, print predictions and reports.

Run this file directly from the project root:

    python backend/demo.py

It generates a small synthetic dataset, fits both models, and prints
predictions, probabilities, a suitability report, and a cross-validated
LDA vs QDA comparison to the console. No test framework required.
"""

import numpy as np
from models.group_11_lda_qda import (
    LDAModel,
    QDAModel,
    analyze_suitability,
    compare_lda_qda,
)


def make_demo_dataset() -> tuple[np.ndarray, np.ndarray]:
    """Build a small, clearly separable two-class dataset."""
    rng = np.random.default_rng(42)
    class_no = rng.normal(loc=[-1.0, 0.5], scale=0.4, size=(40, 2))
    class_yes = rng.normal(loc=[1.0, -0.5], scale=0.4, size=(40, 2))
    X = np.vstack([class_no, class_yes]).astype(np.float64)
    y = np.array(["No"] * 40 + ["Yes"] * 40)
    shuffle_order = rng.permutation(X.shape[0])
    return X[shuffle_order], y[shuffle_order]


def main() -> None:
    X, y = make_demo_dataset()
    X_train, y_train = X[:60], y[:60]
    X_test, y_test = X[60:], y[60:]

    print("=" * 60)
    print("1. Fitting LDA and QDA")
    print("=" * 60)
    lda = LDAModel().fit(X_train, y_train)
    qda = QDAModel(reg_param=0.05).fit(X_train, y_train)

    lda_predictions = lda.predict(X_test)
    qda_predictions = qda.predict(X_test)
    lda_probabilities = lda.predict_proba(X_test)

    print(f"True labels:       {y_test.tolist()}")
    print(f"LDA predictions:    {lda_predictions.tolist()}")
    print(f"QDA predictions:    {qda_predictions.tolist()}")
    print(f"LDA classes_ order: {lda.classes_.tolist()}")
    print(f"LDA probabilities (first 5 rows):\n{np.round(lda_probabilities[:5], 3)}")

    lda_accuracy = float(np.mean(lda_predictions == y_test))
    qda_accuracy = float(np.mean(qda_predictions == y_test))
    print(f"\nLDA holdout accuracy: {lda_accuracy:.3f}")
    print(f"QDA holdout accuracy: {qda_accuracy:.3f}")

    print("\n" + "=" * 60)
    print("2. Model metadata")
    print("=" * 60)
    print("LDA metadata:", lda.get_metadata())
    print("QDA metadata:", qda.get_metadata())

    print("\n" + "=" * 60)
    print("3. Suitability analysis")
    print("=" * 60)
    suitability = analyze_suitability(X, y, qda_reg_param=0.05)
    print(f"Detected problem type:   {suitability['target']['problem_type']}")
    print(f"LDA suitable:            {suitability['lda']['suitable']}")
    print(f"QDA suitable:            {suitability['qda']['suitable']}")
    print(f"Can compare:             {suitability['can_compare']}")
    print(f"Structural preference:   {suitability['structural_preference']}")

    print("\n" + "=" * 60)
    print("4. Cross-validated LDA vs QDA comparison")
    print("=" * 60)
    comparison = compare_lda_qda(X, y, n_splits=5, qda_params={"reg_param": 0.05})
    print(f"Recommended model: {comparison['recommended_model']}")
    print(f"Reason: {comparison['recommendation_reason']}")
    for model_name, report in comparison["models"].items():
        print(f"\n{model_name} mean metrics:")
        for metric, value in report["mean_metrics"].items():
            print(f"  {metric:10s} {value:.4f}")


if __name__ == "__main__":
    main()
