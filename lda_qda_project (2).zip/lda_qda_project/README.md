# LDA/QDA Suitability and Comparison Project

This repository is a runnable reference implementation for Group 11. It contains two
independent, platform-compatible classifiers plus an external suitability and
cross-validation layer.

> **This top-level `README.md` and the root `pyproject.toml` are standalone-delivery
> scaffolding only — do not include them in the course pull request.** The real
> `ml-integration` repository already owns its own root-level files. Per the coding
> standards, your group's pull request touches only `backend/models/group_11_lda_qda/`.
> See "Submission checklist" below.

## Repository layout

```text
lda_qda_project/
├── backend/
│   ├── __init__.py
│   └── models/
│       ├── __init__.py
│       ├── base_model.py
│       └── group_11_lda_qda/
│           ├── __init__.py
│           ├── _validation.py
│           ├── lda.py
│           ├── qda.py
│           ├── suitability.py
│           ├── comparison.py
│           ├── test.py
│           ├── requirements.txt
│           └── README.md
├── pyproject.toml
└── README.md
```

`base_model.py` is included only to make this standalone delivery runnable. In the
course integration repository, keep the official `models/base_model.py` unchanged and
copy only `backend/models/group_11_lda_qda/`.

## Quick start

Use Python 3.12 and install the exact dependency versions:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r backend/models/group_11_lda_qda/requirements.txt
python -m pytest
python -m ruff check .
```

The model-specific usage, hyperparameters, label behavior, suitability rules, and
design decisions are documented in
`backend/models/group_11_lda_qda/README.md`.

## Submission checklist

Before opening the pull request against the actual `ml-integration` repository:

- [ ] Copy **only** `backend/models/group_11_lda_qda/` into your branch of the real
      repository. Do not add this top-level `README.md` or root `pyproject.toml` — the
      real repo already has its own.
- [ ] Do not touch `backend/models/base_model.py`, the model registry, anything under
      `backend/tests/`, `frontend/`, or the CI workflow.
- [ ] Run the official `validate_submission.py` against your folder and confirm it
      reports no failures — the checks documented here are a manual audit against the
      written standards, not a substitute for the real validator.
- [ ] Confirm `python -m pytest` (with the real repo's own root config) still passes
      with ≥ 80% branch coverage, and `python -m ruff check .` is clean under the real
      repo's ruff configuration, which may select stricter rules than this standalone
      copy's `[B, E, F, I, UP]`.
- [ ] Double-check your group's deadline in the course schedule.
